// var mongoose=require('mongoose');
// var Product=require('../models/product');
// mongoose.connect('mongodb://127.0.0.1:27017/shop');

// var products=[
//     new Product({
//         imagePath:'https://media.istockphoto.com/photos/red-apple-picture-id184276818?k=20&m=184276818&s=612x612&w=0&h=QxOcueqAUVTdiJ7DVoCu-BkNCIuwliPEgtAQhgvBA_g=',
//         title:'Apple',
//         description:'Good For Health',
//         price:120
// }),

// new Product({
//     imagePath:'https://thumbs.dreamstime.com/b/sliced-orange-fruit-leaves-isolated-white-23331258.jpg',
//     title:'Orange',
//     description:'Good For Health',
//     price:80
// }),

// new Product({
//     imagePath:'https://images.unsplash.com/photo-1528821154947-1aa3d1b74941?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8Y2hlcnJ5fGVufDB8fDB8fA%3D%3D&w=1000&q=80',
//     title:'Cherry',
//     description:'Good For Health',
//     price:100
// })

// ];
// var done=0;
// for(var i=0;i<products.length;i++){
//     products[i].save(function(err,result){
//         done++;
//         if(done==products.length){
//             exit()
//         }
//     });
// }
// function exit()
// {
//     mongoose.disconnect();
// }
